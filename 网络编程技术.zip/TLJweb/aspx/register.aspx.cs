﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand scmd;
    string constr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
         string yhm, sjh, email, mm, qrmm, sex = "男", gmyx="", szwz,szcs;
        yhm = TextBox1.Text;
        sjh = TextBox2.Text;
        email = TextBox5.Text;
        mm = TextBox2.Text;
        qrmm = TextBox3.Text;
        if (RadioButton2.Checked == true) sex = "女";
        for (int i = 1; i < CheckBoxList1.Items.Count; i++)
        {
            if (CheckBoxList1.Items[i].Selected)
                gmyx += CheckBoxList1.Items[i].Value + ",";

        }
        szcs=DropDownList1.SelectedValue+ListBox1.SelectedValue;
        szwz = TextBox6.Text;
       // Label1.Text = "用户名：" + yhm + "," + "手机号：" + sjh + "," + "电子邮件：" + email + "," + "密码：" + mm + "," + "确认密码：" + qrmm + "," + "性别：" + sex + "," + "收货位置：" + szwz+"," + "所在城市：" + szcs;
        try
        {
            conn = new SqlConnection(constr);//新建一个连接
            conn.Open();                    //打开这个连接
            string sql = "insert into uaer(Username,password,gender,city,email,duixiang,shcity) values('" +
            yhm + "','" + mm + "','" + sex + "','" + szcs + "','" + email + "','" + gmyx + "','" + szwz + "')";
            //上面这句话是定义一个sql变量执行插入语句
            scmd = new SqlCommand(sql, conn);//将语句执行给连接
            int flag = scmd.ExecuteNonQuery();//不执行查询执行插入，如果成功返回成功1条，flag=1
            if (flag > 0)//执行成功的话flag为1，大于零
            {
                Response.Write("注册成功！");
            }
            else
                throw (new Exception("注册失败！"));//进行错误验证当flag=0时
        }
        catch (Exception ex)//捕获一场，try和catch一对
        {
            Response.Write(ex.Message);
        }
    }
    protected void  DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
{
    switch (DropDownList1.SelectedIndex)
    {
        case 0:
            ListBox1.Items.Clear();
            ListBox1.Items.Add("沈阳市");
            ListBox1.Items.Add("大连市");
            ListBox1.Items.Add("抚顺市");
            ListBox1.Items.Add("丹东市");
            break;
        case 1:
            ListBox1.Items.Clear();
            ListBox1.Items.Add("哈尔滨市");
            ListBox1.Items.Add("大庆市");
            ListBox1.Items.Add("佳木斯市");
            ListBox1.Items.Add("牡丹江市");
            break;
        case 2:
            ListBox1.Items.Clear();
            ListBox1.Items.Add("吉林市");
            ListBox1.Items.Add("白城市");
            ListBox1.Items.Add("长春市");
            ListBox1.Items.Add("四平市");
            break;
        case 3:
            ListBox1.Items.Clear();
            ListBox1.Items.Add("朝阳区");
            ListBox1.Items.Add("海淀区");
            ListBox1.Items.Add("东城区");
            ListBox1.Items.Add("丰台区");
            break;
}
}

}
