﻿
Partial Class aspx_bjh
    Inherits System.Web.UI.Page

End Class
