﻿
Partial Class aspx_seb
    Inherits System.Web.UI.Page

End Class
