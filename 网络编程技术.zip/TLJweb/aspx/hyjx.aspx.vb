﻿
Partial Class aspx_hyjx
    Inherits System.Web.UI.Page

End Class
