﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand scmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie Ccookie;
        Ccookie = Request.Cookies["color"];
        if (Ccookie == null)
            Ccookie = new HttpCookie("color", "white");
        Panel1.BackColor = Color.FromName(Ccookie.Value);
        string uname, pwd;
        if (Page.IsPostBack)
        {
            uname = TextBox1.Text;
            pwd = TextBox2.Text;
           
            if (RadioButton1.Checked) Ccookie.Value = "Red";
            if (RadioButton2.Checked) Ccookie.Value = "Yellow";
            if (RadioButton3.Checked) Ccookie.Value = "Blue";
            Ccookie.Expires = DateTime.Now.AddMinutes(1);
            Response.Cookies.Add(Ccookie);
            Session["un"] = uname;
        //    Server.Transfer("welcome.aspx");
            string strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            try
            {
               SqlConnection conn = new SqlConnection(strcon);
                conn.Open();
                string sql= "select PassWord from uaer where userName='"+uname+"'";
                SqlCommand scmd = new SqlCommand(sql, conn);
                SqlDataReader flag = scmd.ExecuteReader();

                if (flag.Read())
                {
                    if (pwd.Equals(flag[0]))
                        Server.Transfer("showPro1.aspx");
                    else

                        Response.Write("密码错误");
                }
                else 
                    Response.Write("用户名没有找到");
                flag.Close();
                conn.Close();
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
 }
