﻿
Partial Class aspx_hlhs
    Inherits System.Web.UI.Page

End Class
