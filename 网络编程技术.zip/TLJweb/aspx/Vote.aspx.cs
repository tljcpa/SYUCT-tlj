﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class aspx_Vote : System.Web.UI.Page
{
    protected static int vote1,vote2,vote3;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        vote1++;
        this.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        vote2++;
        this.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        vote3++;
        this.DataBind();
    }
    protected string VotePercent(int vote) 
    {
        float sum = vote1 + vote2 + vote3;
        float per = vote / sum*100;
        return per.ToString("n2")+"%";
    }
}
