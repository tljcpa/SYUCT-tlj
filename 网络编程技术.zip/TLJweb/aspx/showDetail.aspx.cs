﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class aspx_showDetail : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand scmd;
    string strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
    SqlDataReader sdr;
    int id;
    string bname;
    double bprice;
    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Request.QueryString["PID"]);
        Label1.Text = bname;
        conn = new SqlConnection(strcon);
        try
        {
            conn.Open();
            Response.Write("成功链接数据库");
            string sql = "select * from products where PID='" + id + "' ";
            scmd = new SqlCommand(sql,conn);
            sdr = scmd.ExecuteReader();
            if (sdr.Read())
            {
                Lablxh.Text = sdr["Pname"].ToString();
                Lablyj.Text = sdr["Price"].ToString();
                Lablxj.Text = sdr["SMprice"].ToString();
                Labljj.Text = sdr["SPMs"].ToString();
                Image1.ImageUrl = "~/img/" + sdr.GetString(2);
                bname=sdr["Pname"].ToString();
                bprice = Convert.ToDouble(sdr["SMprice"]);
            }
            else
                Label1.Text = "没找到商品";
            sdr.Close();
            conn.Close();
        }
        catch (Exception ex) {
            Label1.Text = ex.Message;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int uid = 0;
        if (Session["un"] == null) {
            Response.Write("<script language='javascript' type='script/javascript'>alert('没登录，请登录！')</script>");
            Server.Transfer("login.aspx");
        }
        string uname = Session["un"].ToString();
        conn = new SqlConnection(strcon);
        try {
            conn.Open();
            string sql = "select UserID from uaer where Username='" + uname + "'";
            scmd = new SqlCommand(sql,conn);
            sdr = scmd.ExecuteReader();
            if (sdr.Read()) {
                uid = Convert.ToInt32(sdr[0]);
            }
            sdr.Close();
            sql = "select PID from Carts where UserID="+uid;
            scmd.CommandText = sql;
            sdr = scmd.ExecuteReader();
            sql = "insert into Carts(UserID,PID,Pname,Num,price) values ("
              + uid + " , " + id + " ,  '" + bname + "'  , 1  ,  " + bprice + ")";
            while (sdr.Read()) {
                if (id == Convert.ToInt32(sdr[0]))
                {
                    sql = "update Carts set Num=Num+1 where UserID= " + uid + "and PID=" + id;
                    break;
                }
            }
            sdr.Close();
            scmd.CommandText = sql;
            int flag = scmd.ExecuteNonQuery();
            if (flag > 0)
                Response.Write("<script type='text/javascript' language='javascript'>alert('成功加入购物车！');</script>");
            else
                Response.Write("<script type='text/javascript' language='javascript'>alert('加入购物车失败！');</script>");
            conn.Close();
        }
        catch(Exception ex){
            Label1.Text=ex.Message;
        }
        }
    }
