﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class aspx_跳转 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strcon;
        SqlConnection conn;
        SqlCommand scmd;
        SqlDataReader sdr;
        string id;
        string bname = "";
        double bprice = 0;
        if (Session["un"] == null)
        {
            Response.Write("<script language='javascript' type='script/javascript'>alert('没登录，请登录!')</script>");
            Server.Transfer("login.aspx");
        }
        int bid = 0;
        int uid = 0;
        if (e.CommandName == "Add")
        {
            bid = Convert.ToInt32(e.CommandArgument);
            string uname = Session["un"].ToString();
            strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\user.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            conn = new SqlConnection(strcon);
            try
            {
                conn.Open();
                string sql = "select UserID from uaer where UserID='" + uname + "'";
                scmd = new SqlCommand(sql, conn);
                sdr = scmd.ExecuteReader();
                if (sdr.Read())
                {
                    uid = Convert.ToInt32(sdr[0]);
                }
                sdr.Close();
                sql = "select * from products where PID=" + bid;
                scmd.CommandText = sql;
                sdr = scmd.ExecuteReader();
                if (sdr.Read())
                {
                    bname = sdr["Pname"].ToString();
                    bprice = Convert.ToDouble(sdr["SMprice"]);
                }
                sdr.Close();
                scmd.CommandText = "insert into Carts(UserID,PID,Pname,Num,price) values ("
              + uid + " , " + bid + " ,  '" + bname + "'  , 1  ,  " + bprice + ")";
                int flag = scmd.ExecuteNonQuery();
                if (flag > 0)
                    Response.Write("成功加入购物车！");
                else
                    Response.Write("加入购物车失败！");
                conn.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        Server.Transfer("showPro1.aspx");
    }

    
}